import ProductCompareAdd from "./components/ProductCompare/ProductCompareAdd"

export default ProductCompareAdd