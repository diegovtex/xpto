import Adulthood from './components/Adulthood';

export default Adulthood;