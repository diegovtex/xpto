import AdulthoodModal from './components/AdulthoodModal';

export default AdulthoodModal;