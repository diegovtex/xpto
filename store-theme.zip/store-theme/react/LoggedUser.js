import LoggedUser from "./components/LoggedUser";

export default LoggedUser