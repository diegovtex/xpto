import LocationProvider from './components/LocationProvider';

export default LocationProvider;