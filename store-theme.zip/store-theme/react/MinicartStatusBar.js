import MinicartStatusBar from './components/CartLimiter/components/StatusBar'

export default MinicartStatusBar
