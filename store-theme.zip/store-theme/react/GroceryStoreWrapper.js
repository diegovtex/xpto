import GroceryStoreWrapper from "./components/GroceryStoreWrapper";

export default GroceryStoreWrapper;
