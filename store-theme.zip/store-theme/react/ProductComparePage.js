import ProductComparePage from "./components/ProductCompare/ProductComparePage"

export default ProductComparePage