import MinicartLimiter from './components/CartLimiter/index'

export default MinicartLimiter
