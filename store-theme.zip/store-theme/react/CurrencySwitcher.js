import CurrencySwitcher from "./components/CurrencySwitcher";

export default CurrencySwitcher;
