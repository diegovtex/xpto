import ProductWrapper from "./components/ProductWrapper";

export default ProductWrapper;