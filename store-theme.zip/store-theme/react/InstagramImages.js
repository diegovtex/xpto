import InstagramImages from './components/Instagram/InstagramImages'

export default InstagramImages