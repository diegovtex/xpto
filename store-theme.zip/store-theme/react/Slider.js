import Slider from './components/Slider';

export default Slider;