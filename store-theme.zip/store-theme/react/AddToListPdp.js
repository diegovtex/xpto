import AddToListPdp from './components/AddToListPdp/index'

export default AddToListPdp