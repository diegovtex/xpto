import AnchorComponent from './components/Anchor/index'
export default AnchorComponent