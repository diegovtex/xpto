import CustomBuyButton from './components/CustomBuyButton';

export default CustomBuyButton;