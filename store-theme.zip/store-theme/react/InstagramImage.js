import InstagramImage from './components/Instagram/InstagramImage'
export default InstagramImage