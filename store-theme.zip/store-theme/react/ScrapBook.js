import ScrapBook from "./components/ScrapBook";

export default ScrapBook;
