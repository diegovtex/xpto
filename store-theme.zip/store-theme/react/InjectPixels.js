import InjectPixels from './components/InjectPixels';

export default InjectPixels;