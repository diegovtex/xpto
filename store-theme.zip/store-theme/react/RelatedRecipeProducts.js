import RelatedRecipeProducts from './components/RelatedRecipeProducts';

export default RelatedRecipeProducts;