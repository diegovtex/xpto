const MyPreferencesLink = ({ render }) => {
  return render([
    {
      name: "My preferences",
      path: "/preferences"
    }
  ]);
};

export default MyPreferencesLink;
