import MyAccountWrapper from "./components/MyAccountWrapper";

export default MyAccountWrapper;
