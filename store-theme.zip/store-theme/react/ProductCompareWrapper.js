import ProductCompareWrapper from "./components/ProductCompare/ProductCompareWrapper"

export default ProductCompareWrapper