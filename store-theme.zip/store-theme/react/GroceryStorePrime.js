import GroceryStorePrime from './components/GroceryStorePrime/index'

export default GroceryStorePrime